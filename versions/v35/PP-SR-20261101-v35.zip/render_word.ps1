param([string]$InputDocx, [string]$OutputPdf)
$ErrorActionPreference = 'Stop'
$docxPath = (Resolve-Path -LiteralPath $InputDocx).Path
$pdfPath = [System.IO.Path]::GetFullPath($OutputPdf)
$officeInstance = New-Object -ComObject Word.Application
try {
    $officeInstance.Visible = $false
    $officeInstance.DisplayAlerts = 0
    $officeInstance.AutomationSecurity = 3
    $document = $officeInstance.Documents.Open($docxPath, $false, $true, $false)
    $document.Repaginate()
    $pages = $document.ComputeStatistics(2)
    $document.ExportAsFixedFormat($pdfPath, 17)
    $sectionEvidence = @()
    foreach ($section in $document.Sections) {
        $setup = $section.PageSetup
        $sectionEvidence += @{ Width = $setup.PageWidth; Height = $setup.PageHeight; Top = $setup.TopMargin; Bottom = $setup.BottomMargin; Left = $setup.LeftMargin; Right = $setup.RightMargin; Columns = $setup.TextColumns.Count }
    }
    @{ Pages = $pages; Sections = $sectionEvidence; Renderer = 'Microsoft Word native read-only export'; SourceSaved = $false } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath ($pdfPath + '.render.json') -Encoding utf8
    Write-Output ('Pages: ' + $pages)
    $document.Close(0)
} finally {
    $officeInstance.Quit()
}
