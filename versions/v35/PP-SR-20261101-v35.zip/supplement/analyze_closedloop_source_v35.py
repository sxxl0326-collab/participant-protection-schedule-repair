"""Join old and new closed-loop records without rerunning old policies."""
from pathlib import Path
from collections import Counter
from statistics import mean
import json,gzip,csv,hashlib
from copy import deepcopy
import numpy as np
from study_v6.sessions import load_inputs
from study_v6 import common as c

OUT=c.ROOT/'results/revision_v35_20261101'
POLICIES=('First','Random','RoundRobin','LeastRecent','Linear')
OLD=c.ROOT/'results/revision_v20_20261027'

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
def bootstrap(values,sizes):
    a=np.asarray(values);sizes=np.asarray(sizes);rng=np.random.default_rng(2026110101)
    ix=np.concatenate([rng.choice(np.flatnonzero(sizes==k),(10000,sum(sizes==k)),replace=True) for k in sorted(set(sizes))],axis=1)
    return dict(mean=float(a.mean()),ci=np.quantile(a[ix].mean(1),[.025,.975]).tolist(),
                better=int((a<0).sum()),ties=int((a==0).sum()),worse=int((a>0).sum()))

def main():
    proto=read(OUT/'own_history/protocol.json');newsummary=read(OUT/'own_history/summary.json')
    assert newsummary['status']=='PASS'
    rows=[];records={};sameP=sameCG=0
    for mid in proto['models']:
        item,manifest,ledger,_=load_inputs(mid)
        old=read(OLD/'models'/f'{mid}.json');new=read(OUT/'own_history/models'/f'{mid}.json')
        assert old['finished'] and new['finished']
        days=[]
        for day in range(20):
            a,b=old['days'][day],new['days'][day];assert a['event']==b['event']==ledger['days'][day]['accepted']['event']
            ps={**a['policies'],**b['policies']};assert set(ps)==set(POLICIES)
            sameP+=len({tuple(q['P']) for q in ps.values()})==1
            sameCG+=len({(q['witness']['c'],q['witness']['g']) for q in ps.values()})==1
            days.append(dict(day=day,event=a['event'],cstar=a['cstar'],gstar=a['gstar'],
                             setup_witness=ledger['days'][day]['accepted']['setup']['witness'],policies=ps))
        stats={}
        for s in POLICIES:
            qs=[d['policies'][s] for d in days];n=item['d']['workers'];h=[0]*n;shift=[0]*n
            for d,q in zip(days,qs):
                assert q['history_before']==h
                for w in set(q['witness']['affected'])-{d['event']['worker']}:h[w]+=1
                assert q['history_after']==h
                shift=[x+y for x,y in zip(shift,q['intensity']['absolute_start_shift'])]
            delivered=sum(q['delivered'] for q in qs)
            refused=sum(not q['delivered'] and q['response']['status']=='menu_certified_unprotectable' for q in qs)
            unknown=20-delivered-refused
            stats[s]=dict(max_I=max(h),max_shift=max(shift),delivered=delivered,refusals=refused,unknown=unknown,
                C=sum(q['witness']['c'] for q in qs),G=sum(q['witness']['g'] for q in qs),
                concession_days=sum(q['response']['selected_delta_c']>0 or q['response']['selected_delta_g']>0 for q in qs),
                actual_extra_C=sum(q['witness']['c']-d['cstar'] for d,q in zip(days,qs)),
                actual_extra_G=sum(q['witness']['g']-d['gstar'] for d,q in zip(days,qs)),
                seconds=sum(q['total_seconds'] for q in qs),states=dict(Counter(q['status'] for q in qs)),
                raw_states=dict(Counter(q['raw']['status'] if q['raw'] else 'NOT_APPLICABLE' for q in qs)),
                response_states=dict(Counter(q['response']['status'] for q in qs)))
        rows.append(dict(model_id=mid,size=item['size'],policies=stats))
        exported_item=deepcopy(item);exported_item['deadline']=manifest['deadline']
        records[mid]=dict(item=exported_item,size=item['size'],days=days)
    policies={}
    for s in POLICIES:
        policies[s]=dict(mean_max_I=mean(r['policies'][s]['max_I'] for r in rows),mean_max_shift=mean(r['policies'][s]['max_shift'] for r in rows),
            **{k:sum(r['policies'][s][k] for r in rows) for k in ['delivered','refusals','unknown','C','G','concession_days','actual_extra_C','actual_extra_G','seconds']},
            **{k:dict(sum((Counter(r['policies'][s][k]) for r in rows),Counter())) for k in ['states','raw_states','response_states']})
        assert sum(policies[s][k] for k in ['delivered','refusals','unknown'])==1000
    effects={s:bootstrap([r['policies']['Linear']['max_I']-r['policies'][s]['max_I'] for r in rows],[r['size'] for r in rows]) for s in POLICIES if s!='Linear'}
    pool=read(c.ROOT/'paper/v29/supplement/v24_pure_summary.json')
    pool_effects={s:bootstrap([r['arms']['AcceptedRequests']['max_I']['Linear']-r['arms']['AcceptedRequests']['max_I'][s] for r in pool['rows']],
                            [r['size'] for r in pool['rows']]) for s in ['RoundRobin','LeastRecent']}
    out=dict(status='PASS',models=50,days_per_policy=1000,policies=policies,rows=rows,burden_effects=effects,
             all_five_same_request_days=sameP,all_five_same_actual_CG_days=sameCG,common_pool_effects=pool_effects,
             query_seconds=4,selection_seconds=4,bootstrap=dict(unit='model',strata='30/60 activities',replicates=10000,seed=2026110101),
             scope='Own-history closed loop: requests, menus, actual C/G and timing batches differ. Equal delivery counts do not imply identical requested protections or equal costs. First/Random/Linear reuse frozen V20 records; recency/rotation are new V35 solves. Full-budget setup proofs excluded from recorded response+selection/check seconds.')
    save(OUT/'closedloop_summary.json',out)
    (OUT/'closedloop_records.json.gz').write_bytes(gzip.compress(json.dumps(records,separators=(',',':')).encode(),mtime=0))
    with (OUT/'closedloop_policies.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['policy','delivered','refusals','unknown','C','G','concession_days','mean_max_I','mean_max_shift','recorded_seconds','OPTIMAL','FEASIBLE','FALLBACK','CHECKED_RESPONSE'])
        for s,q in policies.items():w.writerow([s,*[q[k] for k in ['delivered','refusals','unknown','C','G','concession_days','mean_max_I','mean_max_shift','seconds']],*[q['states'].get(k,0) for k in ['OPTIMAL','FEASIBLE','FALLBACK','CHECKED_RESPONSE']]])
    print(json.dumps({k:v for k,v in out.items() if k!='rows'},ensure_ascii=False))

if __name__=='__main__':main()
