"""Offline standard-library check of saved files, not a rerun of experiments."""
from pathlib import Path
from zipfile import ZipFile
import hashlib,json

H=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((H/'delivery_manifest.json').read_text(encoding='utf-8'))
for name,digest in manifest['files'].items():
    assert sha((H/name).read_bytes())==digest,'File changed or missing: '+name
base=json.loads((H/'computational_evidence/BASE_EVIDENCE.json').read_text(encoding='utf-8'))
archive=H/'computational_evidence'/base['archive']
assert sha(archive.read_bytes())==base['sha256']
with ZipFile(archive) as z:
    assert z.testzip() is None
    retained=json.loads(z.read('COMPUTATIONAL_MANIFEST.json'))['retained_files']
    for name,digest in retained.items():assert sha(z.read(name))==digest,name
template=json.loads((H/'template_contract.json').read_text(encoding='utf-8'))
assert sha((H/'reference-template.docx').read_bytes())==template['sha256']
with ZipFile(H/'CSCWD2027_Participant_Protection_review.docx') as z:
    for name in ['word/styles.xml','word/numbering.xml','word/footnotes.xml','word/theme/theme1.xml']:
        assert sha(z.read(name))==template['parts'][name],name
print(json.dumps({'status':'PASS_SAVED_PACKAGE','version':manifest['version'],
                  'package_files_checked':len(manifest['files']),
                  'saved_computational_files_checked':len(retained),
                  'experiments_rerun':False}))
