"""Public offline entry: byte integrity plus independent saved-evidence replay."""
from pathlib import Path
import importlib.util,runpy,tempfile,json
H=Path(__file__).resolve().parent
runpy.run_path(str(H/'verify_saved_package.py'),run_name='__main__')
spec=importlib.util.spec_from_file_location('recompute_tables',H/'recompute_tables.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
with tempfile.TemporaryDirectory(prefix='ppsr_verify_') as output:report=module.main(output)
assert report['status']=='PASS'
print(json.dumps({'status':'PASS','version':'PP-SR-20261101-v35','solver_calls':0,
                  'checked':'File hashes, template parts, Tables II/III and closed-loop trajectories; no external UNSAT proofs.'}))
