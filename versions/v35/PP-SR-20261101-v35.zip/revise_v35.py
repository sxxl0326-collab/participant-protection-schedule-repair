"""Evidence-bound protocol revision with fully reported closed-loop extension."""
from pathlib import Path
from copy import deepcopy
from zipfile import ZipFile
import hashlib,json,shutil

H=Path(__file__).resolve().parent;O=H.parent/'v34';ROOT=H.parents[1]
NEW=ROOT/'results/revision_v35_20261101'
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def fmt(x):return f'{x:.2f}'
q=load(NEW/'closedloop_summary.json');assert q['status']=='PASS' and q['models']==50
for name in ['build_word.py','render_word.ps1','reference-template.docx','template_contract.json',
             'references.bib','terminology_ledger.json','figure_design_manifest.json','verify_saved_package.py']:
    shutil.copy2(O/name,H/name)
for name in ['figures','computational_evidence','supplement']:shutil.copytree(O/name,H/name,dirs_exist_ok=True)
for name in ['build','rendered','template_qa']:(H/name).mkdir(exist_ok=True)
for source,target in [('closedloop_summary.json','closedloop_summary_v35.json'),
                      ('closedloop_records.json.gz','closedloop_records_v35.json.gz'),
                      ('closedloop_policies.csv','closedloop_policies_v35.csv')]:
    shutil.copy2(NEW/source,H/'supplement'/target)
shutil.copy2(ROOT/'study_v35/verify_closedloop.py',H/'supplement/verify_closedloop_v35.py')
shutil.copy2(ROOT/'study_v35/own_history.py',H/'supplement/own_history_source_v35.py')
shutil.copy2(ROOT/'study_v35/analyze.py',H/'supplement/analyze_closedloop_source_v35.py')
shutil.copy2(NEW/'own_history/protocol.json',H/'supplement/own_history_protocol_v35.json')

m=load(O/'manuscript.json');old=deepcopy(m)
m['pages'][0]['items'][0]['text']=(
 'After a workforce disruption, equally stable schedule repairs can affect different people. '
 'We present a coordinator–participant protocol that distinguishes incidental satisfaction, '
 'checked protection commitments, solver-confirmed refusals and unresolved search, while tracking '
 'adopted repairs and offering bounded concessions. On 50 public project models over 20 simulated '
 'workdays, Exact and twenty-sample coordination both deliver 88.7%; Exact confirms 113 infeasible '
 'requests left unresolved by sampling. At matched daily stability, Random, Round-robin, '
 'Least-recent and Burden-aware already satisfy about 93–96% of acceptable requests without '
 'protection constraints. With requests enforced, Burden-aware lowers the mean of each model’s '
 'maximum personal impact count from Random’s 4.28 to 3.30 days. Its advantage over Least-recent '
 'varies across sensitivity checks. These results support combining explicit request handling '
 'with history-aware selection.')
m['pages'][0]['items'][5]['text']=(
 'We evaluate protection requests at proved repair optima and track the cumulative impact '
 'of adopted responses. We contribute:')

model=m['pages'][1]['items']
model[4]['text']=(
 'At C*,G*, queries a_w = 0 and 1 classify non-outage workers as forced (protection '
 'infeasible), safe (impact infeasible) or flexible (both feasible). UNKNOWN leaves them '
 'unclassified. A map uses at most 2(|W|−1) calls. With complete classification, affected '
 'sets vary iff F is nonempty.')
model[5]['text']=(
 'Proposition 1. Fix proved C*,G*, complete non-outage classification and outage-impact '
 'flags. Let O contain impacted outage workers. Exactly k = G* − n_f − |O| flexible '
 'workers are impacted, where n_f counts forced non-outage workers. If k = 1, every '
 'proper subset of F is protectable. Proof: forced/outage impact is n_f + |O|; safe '
 'workers contribute zero. Each flexible worker can be the sole flexible impact; '
 'choose one outside P to protect P. For k > 1, capacity alone is insufficient.')
core=model.pop(9)
assert core['text'].startswith('Core diagnostics')
core['text']=('Core diagnostics guard requests, freezes and C/G caps against hard constraints; '
 'unselected guards are disabled. Remove guards only after INFEASIBLE. Subset-minimality '
 'requires feasibility after every remaining deletion; UNKNOWN leaves minimality unresolved.')
model[-1]['text']=(
 'Let ℱ(c,g) contain all repairs satisfying the hard constraints and C(x) ≤ c, G(x) ≤ g, '
 'without protection constraints. Residual requested impact is')
model.append(dict(kind='residual_equation'))
model.append(dict(kind='p',text=(
 'Set R = +∞ for empty ℱ; otherwise R = 0 iff P is jointly protectable. R is nonincreasing '
 'in each cap. Search ΔC,ΔG ≤ Δ = 4 with O(Δ) staircase calls in resolved boxes. '
 'Confirm frontier points only after ruling out cheaper dominating budgets; UNKNOWN '
 'leaves the frontier incomplete.')))
m['pages'][2]['items'].insert(1,core)
stats=m['pages'][2]['items'][-1]
assert stats['text'].startswith('Computational intervals')
stats['text']=stats['text'].replace('Computational intervals use 10,000 model bootstrap resamples within size strata.',
 'We compute 95% confidence intervals using 10,000 size-stratified model bootstrap resamples.')
m['pages'][2]['items'].append(dict(kind='p',text=(
 'Own-history replay adds Least-recent and Round-robin to archived First/Random/Burden-aware '
 'on all fifty models. Each policy requests its own top-three; queries and selection each '
 'receive four seconds. Requests and budgets diverge; outcomes, costs, impact and status '
 'are reported separately.')))

result=m['pages'][3]['items']
result[2]['text']=(
 'Exact and Sample-20 deliver 86.6% strictly and 88.7% under the concession menu (Fig. 2a), '
 'with 21 rescued requests. At equal delivery, Exact confirms all 113 remaining History '
 'requests infeasible; Sample-20 leaves them unresolved. Sample-5 misses 114, including one '
 'feasible request. Uniform menu delivery is 89.9%/89.7% for Exact/Sample-20; its 103 '
 'sampling misses comprise 100 refusals, two feasible requests and one unresolved query. '
 'A checked sampled repair also supports a positive protection commitment.')
result[6]['text']=(
 'At common budgets, First naturally delivers 54.0%/94.5% of acceptable History/Uniform '
 'requests; the other rules deliver 93.1–95.4%/95.1–96.3%. Enforcing protection adds '
 '408 deliveries for First and 41–61 for each alternative rule (50 for Burden-aware). '
 'History requests target First’s prior impacts, so its gain is not representative. '
 'Burden-aware’s maximum-impact change is −0.06 days (95% CI [−0.32,0.12]); '
 'Round-robin/Least-recent change by +0.10/+0.08.')
result[7]['text']=(
 'The 278 acceptable History requests with witnessed flexible members have mean f = 10.17; '
 '273 are on the strict face (mean k = 1.04). For each saved pool let f count witnessed '
 'flexible workers, h their impacts per repair and m their request overlap. The idealized '
 'uniform-subset reference is comb(f−m,h)/comb(f,h), averaged equally over these 278 requests: '
 '82.7%. Random delivers 240/278 (86.3%) on the same requests. Random-weight optimization '
 'is not uniform subset sampling; the reference omits unwitnessed members and compatibility '
 'constraints. The other 609 acceptable requests remain unclassified, not certified safe.')

hist=m['pages'][4]['items']
hist[3]['text']=hist[3]['text'].replace('On 977 jointly OPTIMAL days, including Random, those three policies yield',
 'Recounting the original trajectories only on 977 jointly OPTIMAL days, including Random, '
 'those three policies yield')
hist[3]['text']=hist[3]['text'].replace('With identical saved candidate pools and no selector solver calls,',
 'This conditional sensitivity retains the original decision histories, including earlier '
 'fallbacks; it is not a rerun without solver effects. With identical saved candidate pools '
 'and no selector solver calls,')
pool=q['common_pool_effects']['RoundRobin']
hist[3]['text']+=f' The common-pool Round-robin mean is 4.04 (Burden-aware 3.30).'

v=q['policies'];lr=q['burden_effects']['LeastRecent']
hist[5]['text']=(
 'Own-history outcomes are shown in Table IV. Burden-aware and Least-recent tie on '
 'maximum count in all fifty models, but deliver 877/880 requests at total C = 2,229/2,233 '
 'and G = 2,792 each. Recorded response/selection costs and O/F/B counts are in the '
 'versioned artifact. Supporting no-request tests give Minimax/Burden-aware 3.34/3.32 '
 '(49/50 ties); Count-first (2+2 seconds) gives count/shift 3.38/60.52 versus 3.32/81.84. '
 'Offline column upper bounds and global relaxation lower bounds prove the archived '
 'four-second Burden-aware final maximum count optimal in 20/25 small models; '
 'mean excess lies in [0.16,0.24].')
rows=[['Policy','D/R/U','Max I','Shift','ΣC/ΣG','Menu']]
labels={'First':'First','Random':'Random','RoundRobin':'Round-robin','LeastRecent':'Least-recent','Linear':'Burden-aware'}
for s in ['First','Random','RoundRobin','LeastRecent','Linear']:
 a=v[s];rows.append([labels[s],f'{a["delivered"]}/{a["refusals"]}/{a["unknown"]}',fmt(a['mean_max_I']),
                     fmt(a['mean_max_shift']),f'{a["C"]}/{a["G"]}',a['concession_days']])
hist.insert(6,dict(kind='table',caption=(
 'Own-history replay (4 s/query and selection). D/R/U = delivered/refused/unresolved; '
 'Menu = days adopting concessions. Requests and actual C,G vary by policy; '
 'shift uses benchmark time units.'),rows=rows,weights=[1.4,1.7,.8,1,1.65,.75]))
hist[7]['text']=hist[7]['text'].replace(
 'These constructed cohorts expose compatibility boundaries rather than field frequencies.',
 'The constructed cohorts test protection near and above the compatibility boundary.')

disc=hist[8:]
assert disc[0]['text']=='Discussion and Future Work'
disc[1]['text']=(
 'Collaborative shift scheduling reconciles coworkers’ requests [7, 8], while procedural '
 'justice examines transparency and outcome control [20]. The protocol supports explicit '
 'responses and coordinator authorization. Equal impact counts do not measure subjective '
 'harm. Human acceptance and perceived fairness were not evaluated.')
disc[2]['text']=(
 'History requests target First’s prior impacts, so its delivery gain is specific to this '
 'stress test. Deployment requires request priorities and appeals; strategic request behaviour '
 'is outside this evaluation. Constructed outage cohorts do not estimate field frequencies.')
disc.insert(3,dict(kind='p',text=(
 'The protocol separates a checked protection commitment, a solver-confirmed refusal and '
 'an unresolved search. In matched simulations, selection satisfies many requests '
 'incidentally; protection constraints secure the remaining feasible requests. '
 'Burden-aware reduces repeated impact relative to Random and Round-robin, while its '
 'advantage over Least-recent is not robust across all checks. These findings support '
 'combining explicit request handling with history-aware choice.')))
for item in disc:
 if item.get('text','').startswith('Computational artifacts:'):
  item['text']=('Computational artifacts: https://github.com/sxxl0326-collab/'
    'participant-protection-schedule-repair/tree/main/versions/v35. '
    'Evidence identifier: PP-SR-20261101-v35.')
m['pages'][4]['items']=hist[:8]+disc[:3]
m['pages'][5]['items']=disc[3:]+m['pages'][5]['items']
save(H/'manuscript.json',m)

# Native OMML for the new optimization-domain equation.
b=H/'build_word.py';s=b.read_text(encoding='utf-8')
native="""elif k=='residual_equation':
                p=paragraph('',style='equation')
                om=add(p,'m:oMath')
                def mr(parent,value,plain=False):
                    r=add(parent,'m:r')
                    if plain:add(add(r,'m:rPr'),'m:sty',**{'m:val':'p'})
                    add(r,'m:t').text=value
                mr(om,'R(c,g;P) = ')
                limit=add(om,'m:limLow');mr(add(limit,'m:e'),'min',True)
                mr(add(limit,'m:lim'),'x ∈ ℱ(c,g)')
                summ=add(om,'m:nary');pr=add(summ,'m:naryPr')
                add(pr,'m:chr',**{'m:val':'∑'});add(pr,'m:limLoc',**{'m:val':'subSup'})
                add(pr,'m:grow',**{'m:val':'0'})
                mr(add(summ,'m:sub'),'w ∈ P');add(summ,'m:sup')
                expr=add(summ,'m:e');sub=add(expr,'m:sSub')
                mr(add(sub,'m:e'),'a');mr(add(sub,'m:sub'),'w');mr(expr,'(x)')
            elif k=='equation':"""
assert "elif k=='residual_equation'" not in s
s=s.replace("elif k=='equation':",native)
s=s.replace('if n==7:','if n in (6,7):')
b.write_text(s,encoding='utf-8')
save(H/'revision_notes_v35.json',dict(version='v35',date='2026-11-01',
    focus='Checked commitments and determined responses, not universal protection gains.',
    new_experiment='Own-history Least-recent and Round-robin on the original 50x20 events.',
    conditional_analysis='977 days are recounted within saved trajectories, not rerun.',
    probability_reference='278-request equal-weight idealized uniform-subset reference, not a sampling baseline.',
    bibliography_preserved=True,author_mode_preserved=True,funding_preserved=True,
    abstract_words=len(m['pages'][0]['items'][0]['text'].split())))
save(H/'source_binding_v35.json',dict(base_manuscript_sha256=sha(O/'manuscript.json'),
    new_summary_sha256=sha(H/'supplement/closedloop_summary_v35.json'),
    new_records_sha256=sha(H/'supplement/closedloop_records_v35.json.gz'),
    archived_computational_evidence_sha256=sha(H/'computational_evidence/PP-SR-computational-evidence-v33.zip')))
print(json.dumps({'status':'V35_SOURCE_READY','abstract_words':len(m['pages'][0]['items'][0]['text'].split()),
                  'closed_loop_policies':v},ensure_ascii=False))
