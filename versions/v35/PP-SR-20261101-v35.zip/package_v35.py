"""Bind the six-page manuscript to checked computational evidence."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json,shutil,re
import fitz

H=Path(__file__).resolve().parent;O=H.parent/'v34';ROOT=H.parents[1]
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
for n,h in load(O/'delivery_manifest.json')['files'].items():assert sha(O/n)==h,n
m=load(H/'manuscript.json');old=load(O/'manuscript.json')
assert m['references']==old['references'] and m['funding']==old['funding'] and m['author_mode']==old['author_mode']
items=lambda a:[q for p in a['pages'] for q in p['items']]
tables=[q for q in items(m) if q['kind']=='table'];prior=[q for q in items(old) if q['kind']=='table']
assert len(tables)==4 and tables[:3]==prior
own=load(H/'supplement/closedloop_summary_v35.json')
assert own['policies']['LeastRecent']['mean_max_I']==own['policies']['Linear']['mean_max_I']==3.18
assert own['burden_effects']['LeastRecent']['ties']==50
for i,p in enumerate(m['pages']):
    if p.get('top_figure'):
        rel=p['top_figure']['file'];assert sha(H/rel)==sha(O/rel)
tpl=load(H/'template_contract.json')
with ZipFile(H/'CSCWD2027_Participant_Protection_review.docx') as z:
    for n in ['word/styles.xml','word/numbering.xml','word/footnotes.xml','word/theme/theme1.xml']:
        assert hashlib.sha256(z.read(n)).hexdigest()==tpl['parts'][n]
    assert b'limLow' in z.read('word/document.xml') and b'nary' in z.read('word/document.xml')
    assert len([n for n in z.namelist() if n.endswith('.emf')])==4
pdf=fitz.open(H/'CSCWD2027_Participant_Protection_review.pdf');assert len(pdf)==6
text=' '.join(' '.join(p.get_text().split()) for p in pdf)
for value in ['TABLE IV','Proposition 1','113','609','880/120/0','877/123/0','PP-SR-20261101-v35']:
    assert value in text or value.replace(' ','') in text.replace(' ',''),value
for bad in ['eight-student','91.7%','93.8%','No formal ethics','understandable refusals']:
    assert bad not in text,bad
fonts=set()
for i,p in enumerate(pdf,1):
    assert abs(p.rect.width-612)<1 and abs(p.rect.height-792)<1
    for f in p.get_fonts(full=True):
        fonts.add(f[0]);assert pdf.extract_font(f[0])[3]
    for w in p.get_text('words'):assert 0<=w[0]<w[2]<=613 and 0<=w[1]<w[3]<=793
    p.get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False).save(H/f'rendered/page-{i}.png')
review=load(H/'build/visual_review.json');assert review['status']=='PASS'
for row in review['pages']:assert row['sha256']==sha(H/f'rendered/page-{row["page"]}.png')
audit=load(ROOT/'results/revision_v35_20261101/reproduced_tables/verification.json')
assert audit['status']=='PASS' and all(q['status']=='PASS' for q in audit['independent_checks'].values())
save(H/'supplement/saved_table_audit_v35.json',audit)
for n in ['table_II.csv','table_III.csv','table_IV_closedloop.csv']:
    shutil.copy2(ROOT/'results/revision_v35_20261101/reproduced_tables'/n,H/'supplement'/n)
save(H/'validation.json',dict(status='PASS',version='v35',pages=6,tables=4,native_vector_figures=4,
    fonts_embedded=len(fonts),native_OMML_residual_domain=True,previous_versions_unchanged=True,
    computational_tables_II_III_unchanged=True,new_closedloop_models=50,new_closedloop_policy_days=2000,
    independent_closedloop_schedule_checks=audit['independent_checks']['closedloop']['independent_schedule_checks'],
    negative_and_optimality_claims='Saved solver statuses, not independently checked external proof traces',
    human_study_reported=False,AI_and_funding_preserved=True,
    author_samples_retained_by_request=True,uploaded=False))
(H/'README.md').write_text('''# Participant protection evidence v35

Evidence ID: **PP-SR-20261101-v35**, 2026-11-01.

This package binds the six-page working manuscript to its saved computational
evidence. Author samples remain in the working manuscript at the author's request.
It reports computational simulations; it makes no user-study or perceived-fairness claim.

## Verify saved evidence offline

Extract the ZIP into a new directory and run with Python 3.10 or later:

```sh
python -B verify.py
```

The final line must contain `"status": "PASS"`. Only the Python standard library
is needed. The entry checks file hashes/template parts, then independently
replays positive schedules, requests, impacts, adopted histories and objective
arithmetic for Tables II/III and all five closed-loop policies. It makes no new
solver calls and does not validate external UNSAT or optimality proof traces.

## Regenerate the table values

```sh
python -B recompute_tables.py --output reproduced_tables
```

Outputs are `table_II.csv`, `table_III.csv`, `table_IV_closedloop.csv` and
`verification.json`. The closed-loop CSV includes delivered/refused/UNKNOWN,
actual C/G, concessions, maximum count, cumulative shift, recorded stage seconds,
selected statuses and raw solver statuses. First/Random/Burden-aware costs are
from their archived batch; recency/rotation costs are from the new batch.
Those times exclude archived setup proofs and are not a controlled speed test.

## Fresh optimization is a different operation

`verify.py` and `recompute_tables.py` inspect saved runs. They do not rerun the
experiments. Frozen extension rules, source, bootstrap seed and input identities
are in `supplement/own_history_protocol_v35.json`,
`supplement/own_history_source_v35.py`, `supplement/analyze_closedloop_source_v35.py`
and `supplement/closedloop_summary_v35.json`. Fresh optimization needs the original
project layout and documented OR-Tools 9.11 environment; the project command is
`python -m study_v35.own_history run`, followed by `python -m study_v35.analyze`.
Time-limited fresh runs may return different incumbents/statuses. The supported
self-contained route in this archive is saved-evidence replay, not reconstruction
of the complete historical computing environment.

## Important scopes

- The 977-day check recounts saved trajectories; original prior histories remain.
- The 82.7% idealized uniform-subset reference averages the same 278 requests
  used for the observed Random value 240/278; actual random-objective search is
  not assumed to sample feasible subsets uniformly.
- Own-history policies have their own requests and may adopt different C/G.
- UNKNOWN is not a refusal; independent arithmetic obstructions cover only a
  subset of solver-confirmed refusals.
- The MSLIB release identity, upstream citation and input manifests are retained.
  Third-party rights remain with their owners; no new licence is implied.

The package excludes questionnaire materials and individual participant records.
AI assistance is disclosed in the manuscript. This package does not constitute
a conference submission or confirmation of anonymity/camera-ready requirements.
''',encoding='utf-8')
excluded={'delivery_manifest.json','CHECKSUMS.sha256'}
files=sorted(p for p in H.rglob('*') if p.is_file() and
    not {'build','rendered','__pycache__','public_release'}&set(p.relative_to(H).parts)
    and p.name not in excluded and p.suffix!='.pyc' and not (p.parent==H and p.suffix=='.zip'))
manifest=dict(version='v35',archive_id='PP-SR-20261101-v35',files={p.relative_to(H).as_posix():sha(p) for p in files})
save(H/'delivery_manifest.json',manifest)
(H/'CHECKSUMS.sha256').write_text(''.join(v+'  '+k+'\n' for k,v in manifest['files'].items()),encoding='utf-8')
dest=H/'PP-SR-20261101-v35.zip'
with ZipFile(dest,'w',ZIP_DEFLATED) as z:
    for p in files+[H/'delivery_manifest.json',H/'CHECKSUMS.sha256']:z.write(p,p.relative_to(H).as_posix())
with ZipFile(dest) as z:assert z.testzip() is None
print(json.dumps(dict(status='PASS',pages=6,archive_bytes=dest.stat().st_size,pdf_sha256=sha(H/'CSCWD2027_Participant_Protection_review.pdf'),archive_sha256=sha(dest))))
