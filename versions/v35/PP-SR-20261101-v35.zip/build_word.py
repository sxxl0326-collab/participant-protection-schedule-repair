"""Strict-OOXML template patch; original styles/geometry are authoritative."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from copy import deepcopy
import hashlib,json,re,argparse,os
from lxml import etree as E

HERE=Path(__file__).resolve().parent
REFERENCE=Path(os.environ.get('IEEE_WORD_TEMPLATE',str(HERE/'reference-template.docx')))
W='http://purl.oclc.org/ooxml/wordprocessingml/main'
R='http://purl.oclc.org/ooxml/officeDocument/relationships'
M='http://purl.oclc.org/ooxml/officeDocument/math'
WP='http://purl.oclc.org/ooxml/drawingml/wordprocessingDrawing'
A='http://purl.oclc.org/ooxml/drawingml/main'
PIC='http://purl.oclc.org/ooxml/drawingml/picture'
REL='http://schemas.openxmlformats.org/package/2006/relationships'
NS={'w':W};XML='http://www.w3.org/XML/1998/namespace'
def tag(n):
    p,l=n.split(':');return '{'+{'w':W,'r':R,'m':M,'wp':WP,'a':A,'pic':PIC}[p]+'}'+l
def el(n,**attrs):return E.Element(tag(n),{tag(k) if ':' in k else k:str(v) for k,v in attrs.items()})
def add(parent,n,**attrs):x=el(n,**attrs);parent.append(x);return x
def sha(b):return hashlib.sha256(b).hexdigest()

def build(data,output):
    evidence=json.loads((HERE/'template_contract.json').read_text(encoding='utf8'))
    assert sha(REFERENCE.read_bytes())==evidence['sha256']
    with ZipFile(REFERENCE) as z:parts={n:z.read(n) for n in z.namelist()}
    root=E.fromstring(parts['word/document.xml']);body=root.find('w:body',NS)
    original_sections=root.findall('.//w:sectPr',NS)
    template_author_nodes=[deepcopy(p) for p in list(body)[2:19]]
    funding_node=deepcopy(list(body)[28])
    ft=funding_node.findall('.//w:t',NS)
    for j,t in enumerate(ft):t.text=data.get('funding','') if j==0 else ''
    for node in template_author_nodes:
        for sp in node.findall('.//w:sectPr',NS):
            for ch in list(sp):
                if E.QName(ch).localname in ('footerReference','headerReference','titlePg'):sp.remove(ch)
    two=next(s for s in original_sections if s.find('w:cols',NS).get('{'+W+'}num')=='2')
    one=next(s for s in original_sections if s.find('w:cols',NS).get('{'+W+'}num') is None)
    if data.get('author_mode')=='anonymous_working_copy':
        wrote=False
        for node in template_author_nodes:
            for t in node.findall('.//w:t',NS):
                t.text='Anonymous submission' if not wrote else ''
                wrote=True
    for node in list(body):body.remove(node)
    relroot=E.fromstring(parts['word/_rels/document.xml.rels'])
    images=[];audit=[]

    def runs(p,text,bold=False,italic=False,size=None):
        # Mathematical subscripts are native character formatting, not literal underscores.
        chunks=re.split(r'((?:a|I|D|d|t|T|n|r|𝒞)_(?:w|o|d|e|0|f|t)|[CG]\*)',text)
        for chunk in chunks:
            if not chunk:continue
            match=re.fullmatch(r'([aIDdtTnr𝒞])_([wode0ft])',chunk)
            sup=re.fullmatch(r'([CG])\*',chunk)
            segments=[(match[1],None),(match[2],'subscript')] if match else ([(sup[1],None),('*','superscript')] if sup else [(chunk,None)])
            for txt,va in segments:
                r=add(p,'w:r');rp=add(r,'w:rPr')
                if bold:add(rp,'w:b')
                if italic or match or sup:add(rp,'w:i')
                if size:add(rp,'w:sz',**{'w:val':str(round(size*2))})
                if va:add(rp,'w:vertAlign',**{'w:val':va})
                add(rp,'w:color',**{'w:val':'000000'})
                t=add(r,'w:t');t.set('{'+XML+'}space','preserve');t.text=txt
    def paragraph(text='',style='BodyText',parent=body,**kw):
        p=add(parent,'w:p');pp=add(p,'w:pPr');add(pp,'w:pStyle',**{'w:val':style})
        if kw.get('keep'):add(pp,'w:keepNext')
        if kw.get('unnumbered'):np=add(pp,'w:numPr');add(np,'w:numId',**{'w:val':'0'})
        if kw.get('align'):add(pp,'w:jc',**{'w:val':kw['align']})
        runs(p,text,kw.get('bold',False),kw.get('italic',False),kw.get('size'))
        if style=='references':
            add(pp,'w:keepLines')
            for venue in data.get('reference_italic_venues',[]):
                if venue in text:
                    for r in p.findall('w:r',NS):p.remove(r)
                    before,matched,after=text.partition(venue)
                    runs(p,before,size=kw.get('size'))
                    runs(p,matched,italic=True,size=kw.get('size'))
                    runs(p,after,size=kw.get('size'))
                    break
            for r in p.findall('w:r',NS):
                rp=r.find('w:rPr',NS)
                add(rp,'w:rFonts',**{'w:ascii':'Times New Roman','w:hAnsi':'Times New Roman','w:cs':'Times New Roman'})
                add(rp,'w:spacing',**{'w:val':'0'})
        return p
    def section_end(columns,start='continuous',last=False):
        s=deepcopy(two if columns==2 else one)
        for ref in list(s):
            if E.QName(ref).localname in ('footerReference','headerReference','titlePg'):s.remove(ref)
        typ=s.find('w:type',NS)
        if typ is None:typ=el('w:type');s.insert(0,typ)
        typ.set('{'+W+'}val',start)
        if last:body.append(s)
        else:
            p=add(body,'w:p');pp=add(p,'w:pPr');add(pp,'w:spacing',**{'w:before':'0pt','w:after':'0pt','w:line':'1pt','w:lineRule':'exact'});pp.append(s)
            r=add(p,'w:r');rp=add(r,'w:rPr');add(rp,'w:sz',**{'w:val':'2'})
    def image(path,width=7.24):
        from PIL import Image
        file=Path(path);file=file if file.is_absolute() else HERE/file
        assert file.exists(),file
        with Image.open(file) as im:iw,ih=im.size
        idx=len(images)+1;rid='rIdV16Image'+str(idx);name='v16_'+str(idx)+file.suffix.lower()
        cx=int(width*914400);cy=round(cx*ih/iw)
        p=paragraph('',style='Normal',align='center',keep=True)
        pp=p.find('w:pPr',NS);add(pp,'w:spacing',**{'w:before':'0pt','w:after':'0pt'});r=add(p,'w:r');drawing=add(r,'w:drawing')
        inline=add(drawing,'wp:inline',distT='0',distB='0',distL='0',distR='0')
        add(inline,'wp:extent',cx=cx,cy=cy);add(inline,'wp:effectExtent',l='0',t='0',r='0',b='0')
        add(inline,'wp:docPr',id=str(100+idx),name=name,descr=file.stem.replace('_',' '))
        lock=add(inline,'wp:cNvGraphicFramePr');add(lock,'a:graphicFrameLocks',noChangeAspect='1')
        graphic=add(inline,'a:graphic');gd=add(graphic,'a:graphicData',uri=PIC);pic=add(gd,'pic:pic')
        nv=add(pic,'pic:nvPicPr');add(nv,'pic:cNvPr',id='0',name=name);add(nv,'pic:cNvPicPr')
        bf=add(pic,'pic:blipFill');add(bf,'a:blip',**{'r:embed':rid});stretch=add(bf,'a:stretch');add(stretch,'a:fillRect')
        sp=add(pic,'pic:spPr');tr=add(sp,'a:xfrm');add(tr,'a:off',x='0',y='0');add(tr,'a:ext',cx=cx,cy=cy)
        geom=add(sp,'a:prstGeom',prst='rect');add(geom,'a:avLst')
        rel=E.SubElement(relroot,'{'+REL+'}Relationship');rel.set('Id',rid);rel.set('Type',R+'/image');rel.set('Target','media/'+name)
        parts['word/media/'+name]=file.read_bytes();images.append(dict(file=str(file.relative_to(HERE)) if file.is_relative_to(HERE) else file.name,sha256=sha(file.read_bytes()),width_inches=width,height_inches=cy/914400))
    def table(rows,width=3.495,weights=None):
        tb=add(body,'w:tbl');pr=add(tb,'w:tblPr');add(pr,'w:tblW',**{'w:w':str(round(width*1440)),'w:type':'dxa'})
        add(pr,'w:jc',**{'w:val':'center'});layout=add(pr,'w:tblLayout',**{'w:type':'fixed'})
        borders=add(pr,'w:tblBorders')
        for edge in ('top','left','bottom','right','insideH','insideV'):add(borders,'w:'+edge,**{'w:val':'single','w:sz':'4','w:color':'B3B3B3'})
        grid=add(tb,'w:tblGrid');n=len(rows[0]);weights=weights or [1.9]+[1]*(n-1);assert len(weights)==n;total=sum(weights)
        if n in (6,7):
            margins=add(pr,'w:tblCellMar')
            for edge in ('left','right'):add(margins,'w:'+edge,**{'w:w':'40','w:type':'dxa'})
        widths=[round(width*1440*w/total) for w in weights]
        for w in widths:add(grid,'w:gridCol',**{'w:w':str(w)})
        for i,row in enumerate(rows):
            tr=add(tb,'w:tr')
            if i==0:trp=add(tr,'w:trPr');add(trp,'w:tblHeader')
            for j,value in enumerate(row):
                cell=add(tr,'w:tc');cp=add(cell,'w:tcPr');add(cp,'w:tcW',**{'w:w':str(widths[j]),'w:type':'dxa'});add(cp,'w:vAlign',**{'w:val':'center'})
                paragraph(str(value),style='tablecolhead' if i==0 else 'tablecopy',parent=cell,align='left' if j==0 else 'center',bold=i==0,keep=i<len(rows)-1)
        paragraph('',style='Normal',size=2)
    refs=data.get('references',[])
    for i,page in enumerate(data['pages']):
        if i==0:
            paragraph(data['title'],style='papertitle')
            if data.get('author_mode')=='anonymous_working_copy':
                paragraph('Anonymous submission',style='Author',align='center')
                section_end(1,'continuous')
            else:
                for node in template_author_nodes:body.append(deepcopy(node))
                body.append(funding_node)
        elif page.get('top_figure'):
            f=page['top_figure'];image(f['file'],f.get('width',7.24));paragraph(f['caption'],style='figurecaption')
            section_end(1,'nextPage')
        else:
            # A one-line empty full-width section establishes the next page.
            paragraph('',style='Normal',size=2);section_end(1,'nextPage')
        for item in page['items']:
            k=item['kind'];t=item.get('text','')
            if k=='p':paragraph(t)
            elif k=='abstract':paragraph('Abstract—'+t,style='Abstract')
            elif k=='keywords':paragraph('Keywords—'+t,style='Keywords')
            elif k=='h1':paragraph(t,style='Heading1')
            elif k=='h2':paragraph(t,style='Heading2')
            elif k=='component':paragraph(t,style='Heading5',keep=True)
            elif k=='residual_equation':
                p=paragraph('',style='equation')
                om=add(p,'m:oMath')
                def mr(parent,value,plain=False):
                    r=add(parent,'m:r')
                    if plain:add(add(r,'m:rPr'),'m:sty',**{'m:val':'p'})
                    add(r,'m:t').text=value
                mr(om,'R(c,g;P) = ')
                limit=add(om,'m:limLow');mr(add(limit,'m:e'),'min',True)
                mr(add(limit,'m:lim'),'x ∈ ℱ(c,g)')
                summ=add(om,'m:nary');pr=add(summ,'m:naryPr')
                add(pr,'m:chr',**{'m:val':'∑'});add(pr,'m:limLoc',**{'m:val':'subSup'})
                add(pr,'m:grow',**{'m:val':'0'})
                mr(add(summ,'m:sub'),'w ∈ P');add(summ,'m:sup')
                expr=add(summ,'m:e');sub=add(expr,'m:sSub')
                mr(add(sub,'m:e'),'a');mr(add(sub,'m:sub'),'w');mr(expr,'(x)')
            elif k=='equation':
                p=paragraph(t,style='equation');
                for r in p.findall('w:r',NS):
                    rp=r.find('w:rPr',NS);add(rp,'w:rFonts',**{'w:ascii':'Times New Roman','w:hAnsi':'Times New Roman','w:cs':'Times New Roman'})
            elif k=='figure':image(item['file'],item.get('width',3.49));paragraph(item['caption'],style='figurecaption')
            elif k=='table':
                paragraph(item['caption'],style='tablehead',keep=True)
                if item.get('panels'):
                    for panel in item['panels']:
                        paragraph(panel['label'],style='figurecaption',keep=True,unnumbered=True)
                        table(panel['rows'],weights=item.get('weights'))
                    if item.get('note'):paragraph(item['note'],style='figurecaption',unnumbered=True)
                else:table(item['rows'],weights=item.get('weights'))
            elif k=='references':
                paragraph('References',style='Heading5')
                for ref in refs:paragraph(ref,style='references')
            else:raise ValueError(k)
        # A continuous single-column terminator balances the preceding two
        # columns before the next page; it changes no source paragraph styles.
        if i in (0,1,2,3,4):
            # This page already fills both columns; an extra section terminator
            # would itself spill to an otherwise empty seventh page.
            section_end(2,'continuous',last=i==len(data['pages'])-1)
        else:
            section_end(2,'continuous')
            paragraph('',style='Normal',size=1)
            section_end(1,'continuous',last=i==len(data['pages'])-1)
    parts['word/document.xml']=E.tostring(root,xml_declaration=True,encoding='UTF-8',standalone=True)
    parts['word/_rels/document.xml.rels']=E.tostring(relroot,xml_declaration=True,encoding='UTF-8',standalone=True)
    ct=E.fromstring(parts['[Content_Types].xml']);ctns=E.QName(ct).namespace
    if not any(c.get('Extension')=='png' for c in ct):
        E.SubElement(ct,'{'+ctns+'}Default',Extension='png',ContentType='image/png')
        parts['[Content_Types].xml']=E.tostring(ct,xml_declaration=True,encoding='UTF-8',standalone=True)
    if not any(c.get('Extension')=='emf' for c in ct):
        E.SubElement(ct,'{'+ctns+'}Default',Extension='emf',ContentType='image/x-emf')
        parts['[Content_Types].xml']=E.tostring(ct,xml_declaration=True,encoding='UTF-8',standalone=True)
    core=E.fromstring(parts['docProps/core.xml'])
    for node in core:
        if E.QName(node).localname in ('creator','lastModifiedBy','subject','keywords'):node.text=''
        if E.QName(node).localname=='title':node.text=data['title']
    parts['docProps/core.xml']=E.tostring(core,xml_declaration=True,encoding='UTF-8',standalone=True)
    editable={'word/document.xml','word/_rels/document.xml.rels','[Content_Types].xml','docProps/core.xml'}
    for name,digest in evidence['parts'].items():
        if name not in editable:assert sha(parts[name])==digest,name
    output.parent.mkdir(parents=True,exist_ok=True)
    with ZipFile(output,'w',ZIP_DEFLATED) as z:
        for n,b in parts.items():z.writestr(n,b)
    assert sha(REFERENCE.read_bytes())==evidence['sha256']
    result=dict(status='PASS',template_sha256=evidence['sha256'],docx_sha256=sha(output.read_bytes()),preserved_parts=[n for n in evidence['parts'] if n not in editable],editable_parts=sorted(editable),new_images=images,styles_unchanged=True,numbering_unchanged=True,authors_blank=True,author_block='Original template sample identities intentionally retained by user; actual authors unfilled',public_url=data.get("public_repository"),layout_pages_planned=len(data['pages']))
    (HERE/'template_qa/build_fidelity.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--draft',default='manuscript.json');args=ap.parse_args()
    build(json.loads((HERE/args.draft).read_text(encoding='utf8')),HERE/'CSCWD2027_Participant_Protection_review.docx')
