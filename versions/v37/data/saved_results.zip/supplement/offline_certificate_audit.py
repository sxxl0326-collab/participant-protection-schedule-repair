"""Independent saved-evidence audit of offline bounds and one Hall certificate.

Workspace: python -B revision/v15/offline_certificate_audit.py --workspace
Portable:  python -B offline_certificate_audit.py --projection offline_certificate_projection.json.gz
The portable path uses only the standard library, and never starts an optimizer.
Recorded UNSAT/optimality/best-bound values remain solver claims, not external proof traces.
"""
from pathlib import Path
import argparse
import collections
import copy
import csv
import gzip
import hashlib
import json
import math
import statistics
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]

def read(path):
    return json.loads(path.read_text(encoding="utf-8"))

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def check_witness(item, w):
    d, old, plan = item['d'], item['original'], w['plan']
    starts, crews = plan['start'], plan['allocation']
    assert len(starts) == len(crews) == d['n'] and starts[0] == 0
    occupied = [[] for _ in range(d['workers'])]; changed = 0; affected = set()
    for a, (s, crew) in enumerate(zip(starts, crews)):
        duration = d['duration'][a]; end = s + duration
        assert isinstance(s, int) and s >= 0 and end <= item['deadline'] and end <= starts[-1]
        assert len({person for person, skill in crew}) == len(crew)
        count = [0] * d['skills']
        for person, skill in crew:
            assert isinstance(person, int) and isinstance(skill, int)
            assert 0 <= person < d['workers'] and 0 <= skill < d['skills']
            assert d['workforce'][person][skill]; count[skill] += 1
            if duration:
                occupied[person].append((s, end))
                outage = item['outage']
                if person == outage['worker']: assert end <= outage['start'] or s >= outage['end']
        assert count == d['demands'][a]
        for b in d['successors'][a]: assert end <= starts[b]
        if old['start'][a] < item['outage']['start']:
            assert s == old['start'][a] and sorted(crew) == sorted(old['allocation'][a])
        elif a != 0: assert s >= item['outage']['start']
        before, after = {tuple(x) for x in old['allocation'][a]}, {tuple(x) for x in crew}
        affected.update(person for person, skill in before.symmetric_difference(after))
        if s != old['start'][a]: affected.update(person for person, skill in before | after)
        if duration and (s != old['start'][a] or before != after): changed += 1
    for busy in occupied:
        busy.sort(); assert all(a[1] <= b[0] for a, b in zip(busy, busy[1:]))
    assert w['c'] == changed and w['g'] == len(affected) and w['affected'] == sorted(affected)
    assert (w['c'], w['g']) == (item['cstar'], item['gstar'])

def count_burden(sets, outages, workers):
    return [sum(w in affected and w != o for affected, o in zip(sets, outages)) for w in range(workers)]

def forced_outage(item):
    o = item['outage']; d, old = item['d'], item['original']
    return any(d['duration'][a] > 0 and any(w == o['worker'] for w, k in crew)
        and old['start'][a] < o['end'] and old['start'][a] + d['duration'][a] > o['start']
        for a, crew in enumerate(old['allocation']))

def master_digest(days, workers):
    return digest(dict(workers=workers, days=[dict(item_sha256=d['item_sha256'], gstar=d['gstar'],
        outage=d['outage'], outage_forced_affected=d['outage_forced_affected'], complete=d['complete'],
        columns=[c['affected'] for c in d['columns']]) for d in days]))

def audit_master(days, workers, result, relaxed):
    assert result['relaxed'] is relaxed and result['input_sha256'] == master_digest(days, workers)
    free = [t for t, d in enumerate(days) if relaxed and not d['complete']]
    assert result['free_days'] == free and result['column_days'] == [t for t in range(20) if t not in free]
    assert result['status'] in ('OPTIMAL', 'FEASIBLE', 'UNKNOWN')
    if 'value' not in result: return 0
    assert result['status'] in ('OPTIMAL', 'FEASIBLE')
    assert len(result['affected']) == len(days)
    for t, (d, affected) in enumerate(zip(days, result['affected'])):
        assert len(affected) == len(set(affected)) == d['gstar'] and all(0 <= w < workers for w in affected)
        if t in free:
            if d['outage_forced_affected']: assert d['outage']['worker'] in affected
        else:
            j = result['selected_columns'][str(t)]; assert affected == d['columns'][j]['affected']
    burdens = count_burden(result['affected'], [d['outage']['worker'] for d in days], workers)
    assert result['burden'] == burdens and result['value'] == max(burdens)
    assert result['actual_columns_only'] == (not free)
    assert math.isfinite(result['bound']) and result['bound'] <= result['value'] + 1e-6
    if result['status'] == 'OPTIMAL': assert abs(result['bound'] - result['value']) < 1e-6
    return len(days) - len(free)

def check_hall(item, protected, c):
    d, old, o = item['d'], item['original'], item['outage']; a = c['activity']
    roles = [k for w, k in old['allocation'][a] if w == protected]
    assert len(roles) == 1 and c['protected_worker'] == protected and c['fixed_original_skill'] == roles[0]
    s, e = old['start'][a], old['start'][a] + d['duration'][a]
    assert c['fixed_start'] == s and c['fixed_end'] == e and d['duration'][a] > 0
    demand = list(d['demands'][a]); demand[roles[0]] -= 1
    assert demand == c['remaining_demands'] and all(x >= 0 for x in demand)
    overlap = s < o['end'] and o['start'] < e
    excluded = {protected} | ({o['worker']} if overlap else set())
    assert c['excluded_workers'] == sorted(excluded) and c['outage_overlaps'] == overlap
    slots = [tuple(v) for v in c['hall_slots']]; assert len(slots) == len(set(slots)) and slots
    adjacency = []
    for k, unit in slots:
        assert 0 <= k < d['skills'] and 0 <= unit < demand[k]
        adjacency.append(dict(slot=[k,unit], workers=[w for w in range(d['workers']) if w not in excluded and d['workforce'][w][k]]))
    neighbors = sorted({w for v in adjacency for w in v['workers']})
    assert c['hall_adjacency'] == adjacency and c['hall_neighbors'] == neighbors
    assert c['hall_slot_count'] == len(slots) and c['hall_neighbor_count'] == len(neighbors)
    assert c['deficit'] == len(slots) - len(neighbors) > 0
    return dict(model_id=item['id'], all_indices='One-based in this display; raw archive is zero-based',
        protected_worker=protected+1, activity=a+1, interval=[s,e], skill=roles[0]+1,
        original_crew_roles=[[w+1,k+1] for w,k in old['allocation'][a]],
        skill_holders=[w+1 for w in range(d['workers']) if d['workforce'][w][roles[0]]],
        remaining_slots=[[k+1,u+1] for k,u in slots], neighborhood=[w+1 for w in neighbors],
        S_size=len(slots), N_size=len(neighbors), deficit=c['deficit'],
        outage_worker=o['worker']+1, outage_interval=[o['start'],o['end']],
        overlap_interval=[max(s,o['start']),min(e,o['end'])],
        evidence='Direct slot-neighborhood arithmetic; sufficient, not a unique cause; independent of C/G/deadline relaxation.')

def audit(data):
    assert data['schema'] == 'offline-bound-hall-v15'
    rows, day_rows = [], []; columns_checked = calls_checked = selected_checked = linear_checked = 0
    for packet in data['models']:
        rec = packet['record']; mid = rec['model_id']; workers = rec['workers']; days = packet['days']
        assert rec['size'] == 30 and rec['complete'] and len(days) == len(packet['definitions']) == 20
        assert rec['enumeration_complete_days'] == sum(d['complete'] for d in days)
        assert rec['column_counts'] == [len(d['columns']) for d in days]
        initials = {p:[] for p in ('Default','Random','History')}
        for t, (day, definition) in enumerate(zip(days, packet['definitions'])):
            item = definition['item']; assert definition['day'] == t and day['item_sha256'] == digest(item)
            assert day['finished'] and day['outage'] == item['outage'] and day['gstar'] == item['gstar'] and day['cstar'] == item['cstar']
            assert day['outage_forced_affected'] == forced_outage(item)
            assert len(day['columns']) <= day['cap'] == 128
            known=[]
            for name,w in definition['initial']:
                check_witness(item,w)
                if name in initials: initials[name].append(w['affected'])
                if w['affected'] not in known: known.append(w['affected'])
            for j, call in enumerate(day['calls']):
                assert call['blocked_sets'] == known
                result=call['result']; status=result['status']
                assert 0 < call['allocated_seconds'] <= 4 and status in ('OPTIMAL','FEASIBLE','UNKNOWN','INFEASIBLE')
                if status in ('OPTIMAL','FEASIBLE'):
                    check_witness(item,result['witness']); assert result['witness']['affected'] not in known
                    known.append(result['witness']['affected']); calls_checked += 1
                else: assert j == len(day['calls'])-1 and 'witness' not in result
            assert [c['affected'] for c in day['columns']] == known and len(known) == len({tuple(s) for s in known})
            assert day['complete'] == (day['termination'] == 'exhausted')
            if day['complete']:
                assert day['calls'][-1]['result']['status'] == 'INFEASIBLE' and day['calls'][-1]['blocked_sets'] == known
            elif day['termination'] == 'cap': assert len(known) == 128
            elif day['termination'] == 'UNKNOWN': assert day['calls'][-1]['result']['status'] == 'UNKNOWN'
            else: assert day['termination'] == 'budget'
            for col in day['columns']:
                check_witness(item,col['witness']); assert col['affected'] == col['witness']['affected']
                assert col['nonoutage'] == sorted(set(col['affected'])-{day['outage']['worker']}); columns_checked += 1
            day_rows.append(dict(model_id=mid,day=t,columns=len(known),complete=day['complete'],termination=day['termination'],
                outage_forced_affected=day['outage_forced_affected']))
        outages=[d['outage']['worker'] for d in days]
        for p, sets in initials.items():
            b = count_burden(sets,outages,workers)
            assert rec['baselines'][p] == dict(affected=sets,burden=b,max=max(b))
        for name, relaxed in [('restricted_master',False),('relaxed_master',True)]:
            selected_checked += audit_master(days,workers,rec[name],relaxed)
        linear=packet['linear']; assert linear['complete'] and linear['finished'] and len(linear['days']) == 20
        lsets=[]
        for t,ld in enumerate(linear['days']):
            item=packet['definitions'][t]['item']; assert ld['day'] == t
            assert ld['event']['worker'] == item['outage']['worker'] and ld['event']['start'] == item['outage']['start'] and ld['event']['end'] == item['outage']['end']
            assert (ld['cstar'],ld['gstar']) == (item['cstar'],item['gstar'])
            w=ld['decision']['witness'];check_witness(item,w);lsets.append(w['affected']);linear_checked += 1
        li=max(count_burden(lsets,outages,workers)); assert li == linear['final']['max'] == rec['baselines']['History']['max']
        analytic=math.ceil(sum(max(0,d['gstar']-1) for d in days)/workers)
        lower=analytic; lower_source=['analytic_total_impact']
        bound=rec['relaxed_master']['bound'];assert math.isfinite(bound)
        conservative=math.ceil(bound-1e-7)
        if conservative > lower: lower=conservative;lower_source=['relaxed_master_bound']
        complete=all(d['complete'] for d in days)
        if complete:
            b=rec['restricted_master']['bound'];assert math.isfinite(b)
            if math.ceil(b-1e-7)>lower: lower=math.ceil(b-1e-7);lower_source=['exhaustive_restricted_bound']
        best_name=min(rec['baselines'],key=lambda p:rec['baselines'][p]['max'])
        upper=rec['baselines'][best_name]['max'];upper_source='saved_'+best_name
        for label,name in [('restricted_master','restricted_master'),('relaxed_master_complete_columns','relaxed_master')]:
            m=rec[name]
            if m.get('actual_columns_only') and 'value' in m and m['value']<upper: upper=m['value'];upper_source=label
        assert 0 <= lower <= upper <= li
        expected=dict(lower=lower,upper=upper,upper_source=upper_source,lower_sources=lower_source,
            analytic_lower=analytic,all_days_complete=complete,offline_optimality_proved=lower==upper,
            absolute_gap=upper-lower,relative_gap_over_lower=(upper-lower)/max(1,lower),
            policy_regret_intervals={p:[b['max']-upper,b['max']-lower] for p,b in rec['baselines'].items()})
        assert expected == rec['bounds']
        rows.append(dict(model_id=mid,workers=workers,complete_days=sum(d['complete'] for d in days),
            incomplete_days=sum(not d['complete'] for d in days),columns=sum(len(d['columns']) for d in days),
            lower=lower,upper=upper,lower_source=';'.join(lower_source),upper_source=upper_source,
            relaxed_solver_bound=bound,relaxed_solver_status=rec['relaxed_master']['status'],
            restricted_solver_bound=rec['restricted_master']['bound'],restricted_solver_status=rec['restricted_master']['status'],
            restricted_bound_global_eligible=complete,linear_max=li,linear_excess_low=li-upper,linear_excess_high=li-lower))
    assert len(rows) == 25 and len(day_rows) == 500
    hall = check_hall(data['hall']['item'],data['hall']['protected_worker'],data['hall']['certificate'])
    summary=dict(status='PASS',models=25,days=500,solver_calls=0,
        complete_days=sum(d['complete'] for d in day_rows),incomplete_days=sum(not d['complete'] for d in day_rows),
        checked_columns=columns_checked,checked_enumeration_call_witnesses=calls_checked,
        checked_master_selected_real_columns=selected_checked,checked_linear_witnesses=linear_checked,
        offline_optimum_certified=sum(r['lower']==r['upper'] for r in rows),
        linear_optimal_certified=sum(r['linear_excess_high']==0 for r in rows),
        linear_suboptimal_proved=sum(r['linear_excess_low']>0 for r in rows),
        linear_unresolved=sum(r['linear_excess_low']==0<r['linear_excess_high'] for r in rows),
        linear_mean_excess_interval=[statistics.mean(r['linear_excess_low'] for r in rows),statistics.mean(r['linear_excess_high'] for r in rows)],
        lower_sources=dict(collections.Counter(r['lower_source'] for r in rows)),upper_sources=dict(collections.Counter(r['upper_source'] for r in rows)),
        termination_counts=dict(collections.Counter(d['termination'] for d in day_rows)),
        interpretation='Interval bounds are optimization bounds, not sampling confidence intervals. Actual columns and lifted trajectories checked; exhaustive status and solver best bounds are saved solver claims without external proof traces. Missing columns never constrain an incomplete relaxed day.')
    return summary,rows,day_rows,hall

def workspace():
    sys.path.insert(0,str(ROOT));from study_v4.common import load_base
    v5=ROOT/'results/enhancement_v5_20261017';core=ROOT/'results/core_v4_20261016'
    protocol=read(v5/'offline_bound_protocol.json');sources={}
    def bound(path):
        sources[path.relative_to(ROOT).as_posix()]=sha(path);return read(path)
    for family in ('sources','inputs'):
        for rel,expected in protocol[family].items(): assert sha(ROOT/rel)==expected,rel
    models=[]
    for mid in protocol['models']:
        rec=bound(v5/'offline_bound'/f'{mid}.json');base=load_base(mid)
        assert digest(base)==protocol['input_items_sha256'][mid]
        ledger=bound(core/'workday_setups'/f'{mid}.json');saved=bound(core/'workdays'/f'{mid}.json')
        scene=bound(core/'workday_scenarios'/f'{mid}.json');definitions=[]
        assert saved['complete'] and saved['finished']
        for t,row in enumerate(saved['days']):
            accept=next(r for r in ledger['days'] if r['day']==t)['accepted'];setup=accept['setup']
            assert setup['status']=='OPTIMAL' and row['event']==accept['event']
            assert (row['cstar'],row['gstar'])==(setup['cstar'],setup['gstar'])
            item=copy.deepcopy(base);item.update(outage={k:accept['event'][k] for k in ('worker','start','end')},
                deadline=scene['deadline'],cstar=setup['cstar'],gstar=setup['gstar'])
            initial=[['setup',setup['witness']]]+[[p,row['policies'][p]['decision']['witness']] for p in ('Default','Random','History')]
            definitions.append(dict(day=t,item=item,initial=initial))
        days=[bound(ROOT/p) for p in rec['day_files']]
        for name,label in [('upper','restricted_master'),('lower','relaxed_master')]:
            assert bound(v5/'offline_masters'/mid/f'{name}.json')==rec[label]
        models.append(dict(record=rec,definitions=definitions,days=days,linear=bound(v5/'linear'/f'{mid}.json')))
    hp=v5/'structural/set1_1331_w1.json';hall=bound(hp)
    packet=dict(schema='offline-bound-hall-v15',models=models,
        hall=dict(item=load_base('set1_1331'),protected_worker=1,certificate=hall['selected_certificate']),
        sources=sources)
    return packet

def write_csv(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--workspace',action='store_true');parser.add_argument('--projection',type=Path)
    args=parser.parse_args()
    if args.workspace:
        data=workspace()
    else:
        p=args.projection or HERE/'offline_certificate_projection.json.gz';data=json.loads(gzip.decompress(p.read_bytes()))
    summary,rows,day_rows,hall=audit(data)
    if args.workspace:
        HERE.mkdir(parents=True,exist_ok=True)
        (HERE/'offline_certificate_projection.json.gz').write_bytes(gzip.compress(json.dumps(data,ensure_ascii=False,separators=(',',':')).encode(),mtime=0))
        summary['source_files']=data['sources'];summary['audit_source_sha256']=sha(Path(__file__))
        (HERE/'offline_certificate_audit.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
        (HERE/'hall_example.json').write_text(json.dumps(hall,ensure_ascii=False,indent=2),encoding='utf-8')
        write_csv(HERE/'offline_models25.csv',rows);write_csv(HERE/'offline_day_completeness500.csv',day_rows)
    print(json.dumps({k:v for k,v in summary.items() if k!='source_files'},ensure_ascii=False))
    print(json.dumps(hall,ensure_ascii=False))
    return summary

if __name__=='__main__':main()
