"""Portable fixed-budget acceptability and capacity audit; standard library only."""
from pathlib import Path
from collections import Counter
from fractions import Fraction
from math import comb
from statistics import mean
import gzip,hashlib,json
from v24_witness_check import check

S=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf8'))
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
out=read(S/'v29_evidence.json')
for rel,digest in out['source_sha256'].items():assert hashlib.sha256((S.parent/rel).read_bytes()).hexdigest()==digest,rel
records=load(S/'v24_projection.json.gz');pools=load(S/'v24_pure_records.json.gz')
decisions={(q['model'],q['day']):q for q in out['uniform_classifications']}
statuses=Counter();deliveries=Counter();phys=0;capacity=[];common=[]
for mid,r in sorted(records.items()):
    j=load(S/'joint_requests/models'/(mid+'.json.gz'))
    mask=[q['day'] for q in r['days'] if all(q['arms']['AcceptedRequests'][p]['status']=='OPTIMAL' for p in ['Random','RoundRobin','LeastRecent','Linear'])]
    impacts={p:[0]*j['days'][0]['item']['d']['workers'] for p in r['history']['AcceptedRequests']}
    for i,d in enumerate(r['days']):
        source=j['days'][i];row=source['row'];q=decisions[mid,i];P=set(source['original_requests']['independent_k3'])
        assert (q['C'],q['G'],q['request'])==(d['C'],d['G'],sorted(P))
        if q['status']=='FEASIBLE':
            ref=q['witness_ref'].split('/')
            if ref[0]=='pool':w=pools[mid][i]['pool'][int(ref[1])]
            elif ref[0]=='arms':w=d['arms'][ref[1]][ref[2]]['witness']
            else:assert ref[0]=='joint_witness';w=source['witnesses'][ref[1]]
            check(source['item'],d['event']['start'],[d['event']],w,q['C'],q['G'],P);phys+=1
        else:
            assert q['status']=='INFEASIBLE'
            assert any(v['status']=='INFEASIBLE' and v['cap']==q['dominating_cap']
                and row['cstar']+v['cap'][0]>=q['C'] and row['gstar']+v['cap'][1]>=q['G']
                for v in source['original_group_statuses']['independent_k3'])
        statuses[q['status']]+=1
        for p,v in d['arms']['NoRequest'].items():
            positive=not P.intersection(v['witness']['affected'])
            if positive:assert q['status']=='FEASIBLE'
            deliveries[p]+=positive
        if i in mask:
            for p,v in d['arms']['AcceptedRequests'].items():
                for worker in v['witness']['affected']:
                    if worker!=d['event']['worker']:impacts[p][worker]+=1
        sets=[set(w['affected']) for w in pools[mid][i]['pool']]
        core=set(sets[0]).intersection(*sets);F=set().union(*sets)-core;HP=set(d['P'])
        if d['protect_required'] and HP.intersection(F):
            f=len(F);m=len(HP.intersection(F));h=d['G']-len(core)
            assert all(len(s-core)==h for s in sets) and not HP.intersection(core)
            pred=Fraction(comb(f-m,h),comb(f,h)) if f-m>=h else Fraction(0)
            capacity.append((pred,not HP.intersection(d['arms']['NoRequest']['Random']['witness']['affected'])))
    common.append(dict(model=mid,size=r['size'],retained_days=len(mask),day_mask=mask,max_I={p:max(v) for p,v in impacts.items()}))
assert dict(statuses)==out['uniform_fixed_face_statuses']=={'FEASIBLE':893,'INFEASIBLE':107}
assert phys==893 and len(decisions)==1000
for p,n in deliveries.items():assert n==out['proportions'][p]['uniform_n'] and n/893==out['proportions'][p]['uniform_fraction']
assert len(capacity)==278 and abs(float(sum(p for p,n in capacity)/278)-out['capacity']['predicted_reference'])<1e-12
assert sum(n for p,n in capacity)==out['capacity']['observed_random_n']==240
assert common==out['common_optimal']['rows']==read(S/'v25_completion_sensitivity.json')['rows']
for p,e in out['common_optimal']['effects'].items():
    values=[v['max_I']['Linear']-v['max_I'][p] for v in common]
    assert mean(values)==e['mean'] and [sum(v<0 for v in values),sum(v==0 for v in values),sum(v>0 for v in values)]==[e['better'],e['ties'],e['worse']]
report=dict(status='PASS',new_solver_calls=0,requests=1000,uniform_fixed_face_statuses=dict(statuses),
    independently_checked_positive_schedules=phys,uniform_deliveries=dict(deliveries),
    common_optimal_days=977,common_effects=out['common_optimal']['effects'],
    capacity_reference=float(sum(p for p,n in capacity)/278),capacity_observed_random=240/278,
    scope='Independent positive schedule checker, dominance replay of saved solver-negative statuses, exact-rational capacity arithmetic and conditional exposure recount. Bootstrap CI recomputation is in analyze_v29.py. No external negative proof, uniformity claim for actual CP-SAT output, new human data or causal mechanism claim.')
(S/'v29_saved_audit.json').write_text(json.dumps(report,indent=2),encoding='utf8')
print(json.dumps(report))
