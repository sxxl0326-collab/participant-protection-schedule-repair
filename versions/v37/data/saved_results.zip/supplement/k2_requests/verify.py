"""Independent k2 bridge saved-evidence verifier; Python standard library only."""
from pathlib import Path
from collections import Counter,defaultdict
from statistics import mean
import base64,csv,gzip,hashlib,json,random,math,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent

def read(path):
    data=Path(path).read_bytes();return json.loads(gzip.decompress(data) if str(path).endswith('.gz') else data)
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
def seed(*parts):return int(digest(list(parts))[:8],16)%2147483647
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def witness_check(item,second,witness,cstar=None,gstar=None,P=()):
    d,old,plan=item['d'],item['original'],witness['plan'];starts=plan['start'];crews=plan['allocation']
    assert len(starts)==len(crews)==d['n'] and starts[0]==0
    occupied=[[] for _ in range(d['workers'])];affected=set();changed=0
    for a,(start,crew) in enumerate(zip(starts,crews)):
        duration=d['duration'][a];end=start+duration
        assert isinstance(start,int) and 0<=start and end<=item['deadline'] and end<=starts[-1]
        assert len({w for w,s in crew})==len(crew)
        assigned=[0]*d['skills']
        for w,s in crew:
            assert isinstance(w,int) and isinstance(s,int) and 0<=w<d['workers'] and 0<=s<d['skills']
            assert d['workforce'][w][s];assigned[s]+=1
            if duration:
                occupied[w].append((start,end))
                for outage in (item['outage'],second):
                    if w==outage['worker']:assert end<=outage['start'] or start>=outage['end']
        assert assigned==d['demands'][a]
        for b in d['successors'][a]:assert end<=starts[b]
        if old['start'][a]<item['outage']['start']:assert start==old['start'][a] and sorted(crew)==sorted(old['allocation'][a])
        elif a!=0:assert start>=item['outage']['start']
        before,after={tuple(x) for x in old['allocation'][a]},{tuple(x) for x in crew}
        affected.update(w for w,s in before.symmetric_difference(after))
        if start!=old['start'][a]:affected.update(w for w,s in before|after)
        changed+=bool(duration and (start!=old['start'][a] or before!=after))
    for busy in occupied:
        busy.sort();assert all(x[1]<=y[0] for x,y in zip(busy,busy[1:]))
    assert witness['c']==changed and witness['g']==len(affected) and witness['affected']==sorted(affected)
    if cstar is not None:assert (changed,len(affected))==(cstar,gstar)
    assert not set(P)&affected

def load_call(name,pkg,witnessfiles):
    source=pkg['source_calls'][name];blob=base64.b64decode(source['base64']);assert hashlib.sha256(blob).hexdigest()==source['sha256']
    call=json.loads(blob)
    for raw in [r['result'] for r in call['attempts']]+[call['result']]:
        ref=raw.pop('witness_ref',None)
        if ref:
            saved=witnessfiles[ref['file']];compressed=base64.b64decode(saved['base64'])
            assert hashlib.sha256(compressed).hexdigest()==saved['sha256']==ref['sha256']
            witness=json.loads(gzip.decompress(compressed));assert digest(witness)==ref['content_sha256'];raw['witness']=witness
    return call,source['sha256']

def supplemental_check():
    audit=read(HERE/'supplemental/audit.json');assert audit['status']=='PASS'
    assert sha(HERE/'supplemental/status_audit.py')==audit['source_sha256']
    rows=list(csv.DictReader((HERE/'supplemental/policy_day_statuses.csv').open(encoding='utf-8-sig')))
    summaries=list(csv.DictReader((HERE/'supplemental/policy_statuses.csv').open(encoding='utf-8-sig')))
    assert len(rows)==11000 and len(summaries)==7
    for saved in summaries:
        subset=[r for r in rows if r['policy']==saved['policy']];assert len(subset)==int(saved['days'])
        primary=Counter(r['primary_status'] for r in subset);adopted=Counter(r['adopted_category'] for r in subset)
        for suffix,code in [('optimal','OPTIMAL'),('feasible','FEASIBLE'),('unknown','UNKNOWN')]:assert primary[code]==int(saved['raw_'+suffix])
        for suffix,category in [('proved','proved_objective'),('feasible_unproved','feasible_unproved'),('checked_fallback','checked_fallback'),('feasibility_only','feasibility_only')]:assert adopted[category]==int(saved['adopted_'+suffix])
        assert sum(adopted.values())==len(subset)
        last=[int(r['max_impact']) for r in subset if int(r['day'])==20];assert abs(mean(last)-float(saved['mean_max_count']))<1e-9
    diagnostic=list(csv.DictReader((HERE/'supplemental/minimax_linear_difference_days.csv').open(encoding='utf-8-sig')))
    assert len(diagnostic)==20 and all(r['minimax_raw']==r['linear_raw']=='OPTIMAL' for r in diagnostic)
    assert [int(r['day']) for r in diagnostic if r['same_affected']=='False']==audit['minimax_difference']['affected_sets_differ_days']
    return dict(policy_day_records=len(rows),policies=len(summaries),scope='Supplemental historical status CSV arithmetic, not a fresh physical check of all historical schedules.')

def main():
    manifest=read(HERE/'manifest.json')
    for name,h in manifest['files'].items():assert sha(HERE/name)==h,name
    evidence=read(HERE/'evidence.json.gz');protocol=evidence['protocol'];summary=read(HERE/'summary.json')
    assert len(evidence['models'])==len(protocol['models'])==14
    resultrows=[];checked=0;statuses=Counter();sourcecalls=set()
    for mid,pkg in evidence['models'].items():
        spec=protocol['models'][mid];item=pkg['item'];second=pkg['second'];r=pkg['record'];F=spec['F']
        assert digest(item)==spec['item_sha256'] and second==spec['second']
        assert r['model_id']==mid and r['finished'] and len(r['pool'])==20
        assert r['protocol_sha256']==evidence['original_protocol_sha256']
        assert F==sorted(x['worker'] for x in pkg['map'] if x['classification']=='flexible')
        nf=sum(x['classification']=='forced' for x in pkg['map']);assert spec['gstar']-nf-2==2
        excluded={item['outage']['worker'],second['worker']};assert len(excluded)==2 and not excluded&set(F)
        for name,metric in [('setup_c','c'),('setup_g','g')]:
            raw=pkg[name];assert raw['status']=='OPTIMAL' and raw['cost']==raw['witness'][metric] and abs(raw['cost']-raw['bound'])<1e-6
            witness_check(item,second,raw['witness']);checked+=1
        assert pkg['setup_c']['cost']==spec['cstar'] and pkg['setup_g']['cost']==spec['gstar']
        assert pkg['setup_g']['witness']['c']==spec['cstar']
        rng=random.Random(seed(protocol['request_seed'],'protected_groups_k2',mid));requests=[]
        for k in (2,3,5):
            if k>len(F):continue
            selected=set()
            while len(selected)<min(5,math.comb(len(F),k)):selected.add(tuple(sorted(rng.sample(F,k))))
            requests.extend(dict(k=k,P=list(P)) for P in sorted(selected))
        assert requests==spec['requests']==[dict(k=q['k'],P=q['P']) for q in r['requests']]
        for index,p in enumerate(r['pool']):
            rng=random.Random(seed(protocol['pool_seed'],'shared_random_objective_pool',mid,index))
            weights={str(w):0 if w in excluded else rng.randint(1,10) for w in range(item['d']['workers'])}
            assert p['index']==index+1 and p['weights']==spec['weights'][index]==weights
            raw=p['result'];statuses[raw['status']]+=1;assert raw['status'] in ('OPTIMAL','FEASIBLE','UNKNOWN')
            if raw.get('witness'):
                witness_check(item,second,raw['witness'],spec['cstar'],spec['gstar']);checked+=1
                value=sum(weights[str(w)] for w in raw['witness']['affected']);assert raw['cost']==value and raw['bound']<=value+1e-6
                if raw['status']=='OPTIMAL':assert abs(raw['bound']-value)<1e-6
            else:assert raw['status']=='UNKNOWN'
        for q in r['requests']:
            exact=q['exact'];assert exact['status']=='FEASIBLE'
            call,h=load_call(exact['source_call'],pkg,evidence['witness_files']);sourcecalls.add(exact['source_call'])
            assert h==exact['source_call_sha256'] and call['finished'] and call['result']['status'] in ('OPTIMAL','FEASIBLE')
            claim=call['spec'];B=exact['positive_pair'];assert len(B)==2 and set(B)<=set(F) and not set(B)&set(q['P'])
            assert claim==dict(item_sha256=digest(item),second=second,kind='protect',request=sorted(set(F)-set(B)),cstar=spec['cstar'],gstar=spec['gstar'])
            assert call['result']['witness']==exact['witness']
            witness_check(item,second,exact['witness'],spec['cstar'],spec['gstar'],q['P']);checked+=1
            assert set(exact['witness']['affected'])&set(F)==set(B)
            row=dict(model_id=mid,k=q['k'],P=q['P'],exact='FEASIBLE')
            for K in (5,20):
                matching=[p for p in r['pool'][:K] if p['result'].get('witness') and not set(q['P'])&set(p['result']['witness']['affected'])]
                assert q['sampling'][str(K)]==dict(status='FEASIBLE' if matching else 'UNKNOWN',pool_index=matching[0]['index'] if matching else None)
                row['sample'+str(K)]=bool(matching)
            resultrows.append(row)
    assert resultrows==summary['rows'] and summary['models']==14 and summary['requests']==210 and summary['pool_solves']==280
    assert dict(statuses)==summary['solver_statuses']
    for k in (2,3,5):
        selected=[r for r in resultrows if r['k']==k];saved=summary['by_k'][str(k)]
        assert len(selected)==saved['requests']==70 and saved['exact_statuses']=={'FEASIBLE':70}
        for K in (5,20):
            n=sum(r['sample'+str(K)] for r in selected);assert n==saved[f'sample{K}_delivered']
            assert 70-n==saved[f'sample{K}_miss_on_certified_feasible']
            assert abs(n/70-saved[f'sample{K}_model_mean_delivery'])<1e-9
    result=dict(status='PASS',models=14,requests=210,pool_solves=280,physical_witness_checks=checked,source_pair_calls=len(sourcecalls),solver_calls=0,
        exact_feasible=210,sampling_K5=sum(r['sample5'] for r in resultrows),sampling_K20=sum(r['sample20'] for r in resultrows),supplemental=supplemental_check(),
        scope='Independent physical and arithmetic verification of saved positive evidence. C/G optimality and recorded solver statuses remain solver claims, not external proof traces. No refusal is claimed for sampling misses; no optimizer is imported or run.')
    print(json.dumps(result));return result

if __name__=='__main__':main()
