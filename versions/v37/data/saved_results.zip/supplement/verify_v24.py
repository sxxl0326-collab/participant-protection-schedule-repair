"""Independently replay 2x5 ablation, cache provenance and positive schedules."""
from pathlib import Path
from statistics import mean,pstdev
from collections import Counter
import json,gzip,hashlib,random
from v24_witness_check import check,shift,gin
H=Path(__file__).resolve().parent
readgz=lambda p:json.loads(gzip.decompress(p.read_bytes()))
records=readgz(H/'v24_projection.json.gz');base=readgz(H/'v19_projection.json.gz')['joint'];oldrot=readgz(H/'v23_projection.json.gz')['rotation']
summary=json.loads((H/'v24_factorial_summary.json').read_text(encoding='utf8'));names=list(summary['means']['AcceptedRequests']);arms=('NoRequest','AcceptedRequests');means={a:{p:[] for p in names} for a in arms};delivered={a:Counter() for a in arms};states={a:{p:Counter() for p in names} for a in arms};checks=0;reused=0;newcalls=0;Ctot=Gtot=0
for mid,r in records.items():
 item=base[mid]['item'];old=base[mid]['record'];n=item['d']['workers'];hist={a:{p:[0]*n for p in names} for a in arms};last={a:{p:[-1]*n for p in names} for a in arms};cursor={a:{p:0 for p in names} for a in arms};disp={a:{p:[0]*n for p in names} for a in arms};assert r['finished'] and len(r['days'])==20
 for day,row in enumerate(r['days']):
  prior=old['days'][day];assert (row['event'],row['P'],row['C'],row['G'])==(prior['event'],prior['P'],prior['target_c'],prior['target_g']);e=row['event'];o=e['worker'];Ctot+=row['C'];Gtot+=row['G'];initial=prior['policies']['First']['witness']
  for arm in arms:
   required=row['P'] if arm=='AcceptedRequests' and row['protect_required'] else []
   for p,q in row['arms'][arm].items():
    assert q['required']==required and q['history_before']==hist[arm][p] and q['last_before']==last[arm][p] and q['cursor_before']==cursor[arm][p]
    ring=[(cursor[arm][p]+i)%n for i in range(n) if (cursor[arm][p]+i)%n!=o]
    payload=json.dumps([2026102601,mid,day,'joint_random'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode();seed=int(hashlib.sha256(payload).hexdigest()[:8],16)%2147483647;rng=random.Random(seed)
    if p=='First':weights=None
    elif p=='Random':weights={w:0 if w==o else rng.randint(1,10) for w in range(n)}
    elif p=='Linear':weights={w:0 if w==o else 1+hist[arm][p][w] for w in range(n)}
    elif p=='RoundRobin':weights={w:0 if w==o else ring.index(w)+1 for w in range(n)}
    else:weights={w:0 if w==o else (last[arm][p][w]+1)*(n*n+1)+w for w in range(n)}
    assert weights==(None if q['weights'] is None else {int(k):v for k,v in q['weights'].items()})
    raw=q['raw'];assert raw['status'] not in ('INFEASIBLE','MODEL_INVALID')
    if q['source']=='CACHED_OPTIMAL':
     oq=(oldrot[mid]['days'][day] if p in ('RoundRobin','LeastRecent') else prior)['policies'][p]
     assert raw==oq['raw'] and raw['status']=='OPTIMAL' and weights=={int(k):v for k,v in oq['weights'].items()} and required==(row['P'] if prior['protect_required'] else []);reused+=1
    else:assert q['source']=='NEW_SOLVE';newcalls+=1
    found=raw.get('witness');score=lambda w:sum(weights[i] for i in w['affected']) if weights else 0;use=found is not None and score(found)<=score(initial)
    assert q['witness']==(found if use else initial) and q['status']==(raw['status'] if use else 'FALLBACK')
    w=q['witness'];affected=check(item,e['start'],[e],w,row['C'],row['G'],required);checks+=1
    if found:check(item,e['start'],[e],found,row['C'],row['G'],required);checks+=1
    if weights is not None and found:assert raw['cost']==score(found)
    impacted=affected-{o}
    for worker in impacted:hist[arm][p][worker]+=1;last[arm][p][worker]=day
    if p=='RoundRobin' and impacted:cursor[arm][p]=(max(impacted,key=ring.index)+1)%n
    assert q['history_after']==hist[arm][p] and q['last_after']==last[arm][p] and q['cursor_after']==cursor[arm][p]
    v=shift(item,w,o);assert v==q['shift'];disp[arm][p]=[x+y for x,y in zip(disp[arm][p],v)]
    assert q['delivered']==(not set(row['P'])&affected);delivered[arm][p]+=q['delivered'];states[arm][p][q['status']]+=1
 target=next(q for q in summary['rows'] if q['model_id']==mid)
 for arm in arms:
  for p in names:
   v=hist[arm][p];means[arm][p].append(max(v));q=target['arms'][arm][p]
   for k,value in dict(max_I=max(v),sd=pstdev(v),gini=gin(v),distinct=sum(x>0 for x in v),total_I=sum(v),max_shift=max(disp[arm][p])).items():assert abs(q[k]-value)<1e-10,(mid,arm,p,k)
assert (Ctot,Gtot)==(2235,2794)
for arm in arms:
 for p in names:assert mean(means[arm][p])==summary['means'][arm][p]['max_I']
assert all(v==887 for v in delivered['AcceptedRequests'].values())
report=dict(status='PASS',models=50,days=1000,policy_days=10000,physical_checks=checks,cached_optimal_matches=reused,new_solve_records=newcalls,actual_C_total=Ctot,actual_G_total=Gtot,delivered={a:dict(v) for a,v in delivered.items()},states={a:{p:dict(v) for p,v in ps.items()} for a,ps in states.items()},solver_calls_in_verifier=0,scope='Checks schedules/impact/history/objective/cache provenance and saved states; no independent external proof of negative answers or optimality.')
(H/'v24_saved_replay_audit.json').write_text(json.dumps(report,indent=2),encoding='utf8');print(json.dumps(report))
